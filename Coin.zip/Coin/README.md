# Coin DApp

Built a money transaction application with a minter who can create money to other accounts, and which they can transfer money to other accounts in the network.

<small> The smart contract used is based on the example in solidity docs </small>
